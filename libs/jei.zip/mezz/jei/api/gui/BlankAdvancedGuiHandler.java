package mezz.jei.api.gui;

import net.minecraft.client.gui.inventory.GuiContainer;

/**
 * @deprecated since JEI 4.6.0. This was replaced by default methods in {@link IAdvancedGuiHandler}.
 */
@Deprecated
public abstract class BlankAdvancedGuiHandler<T extends GuiContainer> implements IAdvancedGuiHandler<T> {

}
