@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.api.recipe;

import javax.annotation.ParametersAreNonnullByDefault;

import mcp.MethodsReturnNonnullByDefault;