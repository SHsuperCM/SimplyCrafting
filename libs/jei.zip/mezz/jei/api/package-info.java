@API(apiVersion = "4.13.0", owner = "jei", provides = "JustEnoughItemsAPI")
@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.api;

import javax.annotation.ParametersAreNonnullByDefault;

import net.minecraftforge.fml.common.API;

import mcp.MethodsReturnNonnullByDefault;
